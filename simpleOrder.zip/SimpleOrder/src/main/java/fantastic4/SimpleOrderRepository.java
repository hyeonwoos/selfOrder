package fantastic4;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface SimpleOrderRepository extends PagingAndSortingRepository<SimpleOrder, Long>{

}